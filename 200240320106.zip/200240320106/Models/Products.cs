﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Models
{
    public class Products
    {
        [Required]
        public int ProductId { get; set; }
        [DataType(DataType.Text)]
        [Required(ErrorMessage = "Please Enter a id")]
        [Display(Name = "id")]
        [StringLength(20, ErrorMessage = "The {0} value cannot exceed {1} characters. ")]
        public string ProductName { get; set; }
        [DataType(DataType.Text)]
        [Required(ErrorMessage = "Please Enter a Name")]
        [Display(Name = "Full Name")]
        [StringLength(20, ErrorMessage = "The {0} value cannot exceed {1} characters. ")]
        public decimal Rate { get; set; }
        public int Categoryid { get; set; }
        public int CategoryId { get; internal set; }
        [Required(ErrorMessage = "Please Enter Id")]

        public string Description { get; set; }
        [Required(ErrorMessage = "Please Enter description")]
        public List<SelectListItem> Categories { get; internal set; }
    }
}