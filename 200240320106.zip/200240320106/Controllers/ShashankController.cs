﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ShashankController : Controller
    {
    
          private SqlConnection cn = new SqlConnection();
        // GET: Shashank
        public ActionResult Index()
        {
            List<Products> objEmpList = new List<Products>();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Employees";

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {


                objEmpList.Add(new Products
                {
                    ProductId = Convert.ToInt32(dr["ProductId"]),
                    ProductName = (string)dr["ProductName"],
                    Rate = Convert.ToDecimal(dr["Rate"]),
                    CategoryId = Convert.ToInt32(dr["CategoryId"])
                });

            }
            dr.Close();

            cn.Close();

            return View(objEmpList);
        }

        // GET: Products/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }


        // GET: Shashank/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Shashank/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Shashank/Edit/5
        public ActionResult Edit(int ProductId = 0)
        {

            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";
            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from Products where ProductId = " + ProductId, cn);
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();
            Products p = new Products { ProductId = (int)dr["ProductId"], ProductName = (string)dr["ProductName"], Rate = (decimal)dr["Rate"], Description = (string)dr["Description"], CategoryId = (int)dr["CategoryId"] };
            cn.Close();

            cn.Open();
            List<SelectListItem> objC = new List<SelectListItem>();
            SqlCommand cmd1 = new SqlCommand("select * from Categories", cn);
            SqlDataReader dr1 = cmd.ExecuteReader();
            while (dr1.Read())
            {
                objC.Add(new SelectListItem { Text = dr1["CategoryName"].ToString(), Value = dr1["CategoryId"].ToString() });
            }
            p.Categories = objC;
            cn.Close();
            return View(p);
        }

        // POST: Shashank/Edit/5
        [HttpPost]
        public ActionResult Edit(int? ProductId, Products product)
        {
            try
            {
                // TODO: Add update logic here
                cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";
                cn.Open();

                string sqlq = "update Products set ProductId = @ProductId,ProductName = @ProductName,Rate = @Rate, Description = @Description,CategoryId = @CategoryId where ProductId = " + ProductId;
                SqlCommand cmd = new SqlCommand(sqlq, cn);

                cmd.Parameters.AddWithValue("@ProductId", product.ProductId);
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@Rate", product.Rate);
                cmd.Parameters.AddWithValue("@Description", product.Description);
                cmd.Parameters.AddWithValue("@CategoryId", product.CategoryId);

                cmd.ExecuteNonQuery();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
            finally
            {
                cn.Close();
            }
        }


    }
}

// GET: Shashank/Delete/5
